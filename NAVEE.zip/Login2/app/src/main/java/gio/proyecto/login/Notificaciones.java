package gio.proyecto.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Notificaciones extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.like);
    }

    public void onClick(View view) {

        //Intent miIntent = new Intent(MainActivity.this, Ingresar.class);

        Intent miIntent = null;

        switch (view.getId()) {
            case R.id.favorito:
                miIntent = new Intent(Notificaciones.this, Favoritos.class);
                break;

            case R.id.cusca:
                miIntent = new Intent(Notificaciones.this, Buscar.class);
                break;

            case R.id.home:
                miIntent = new Intent(Notificaciones.this, Ingresar.class);
                break;

            case R.id.noti:
                miIntent = new Intent(Notificaciones.this, Notificaciones.class);
                break;

            case R.id.msj:
                miIntent = new Intent(Notificaciones.this, Mensajes.class);
                break;
        }

        startActivity(miIntent);
    }
}