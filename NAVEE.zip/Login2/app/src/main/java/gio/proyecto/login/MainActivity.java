package gio.proyecto.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

        public void onClick(View view) {

            //Intent miIntent = new Intent(MainActivity.this, Ingresar.class);

            Intent miIntent = null;

            switch (view.getId()){
                case R.id.button:
                    miIntent = new Intent(MainActivity.this, Ingresar.class);
                    break;

                case R.id.button2:
                    miIntent = new Intent(MainActivity.this, Ingresar.class);
                    break;
            }

            startActivity(miIntent);
        }

}