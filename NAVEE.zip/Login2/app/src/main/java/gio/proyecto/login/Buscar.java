package gio.proyecto.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Buscar extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.buscar);
    }

    public void onClick(View view) {

        //Intent miIntent = new Intent(MainActivity.this, Ingresar.class);

        Intent miIntent = null;

        switch (view.getId()) {
            case R.id.favorito:
                miIntent = new Intent(Buscar.this, Favoritos.class);
                break;

            case R.id.cusca:
                miIntent = new Intent(Buscar.this, Buscar.class);
                break;

            case R.id.home:
                miIntent = new Intent(Buscar.this, Ingresar.class);
                break;

            case R.id.noti:
                miIntent = new Intent(Buscar.this, Notificaciones.class);
                break;

            case R.id.msj:
                miIntent = new Intent(Buscar.this, Mensajes.class);
                break;
        }

        startActivity(miIntent);
    }
}
