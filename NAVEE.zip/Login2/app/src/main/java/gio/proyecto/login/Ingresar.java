package gio.proyecto.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;


public class Ingresar extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.principal);
    }
    public void onClick(View view) {

        //Intent miIntent = new Intent(MainActivity.this, Ingresar.class);

        Intent miIntent = null;

        switch (view.getId()) {
            case R.id.favorito:
                miIntent = new Intent(Ingresar.this, Favoritos.class);
                break;

            case R.id.cusca:
                miIntent = new Intent(Ingresar.this, Buscar.class);
                break;

            case R.id.home:
                miIntent = new Intent(Ingresar.this, Ingresar.class);
                break;

            case R.id.noti:
                miIntent = new Intent(Ingresar.this, Notificaciones.class);
                break;

            case R.id.msj:
                miIntent = new Intent(Ingresar.this, Mensajes.class);
                break;
        }

        startActivity(miIntent);
    }
}

