package gio.proyecto.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Mensajes extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.msj);
    }

    public void onClick(View view) {

        //Intent miIntent = new Intent(MainActivity.this, Ingresar.class);

        Intent miIntent = null;

        switch (view.getId()) {
            case R.id.favorito:
                miIntent = new Intent(Mensajes.this, Favoritos.class);
                break;

            case R.id.cusca:
                miIntent = new Intent(Mensajes.this, Buscar.class);
                break;

            case R.id.home:
                miIntent = new Intent(Mensajes.this, Ingresar.class);
                break;

            case R.id.noti:
                miIntent = new Intent(Mensajes.this, Notificaciones.class);
                break;

            case R.id.msj:
                miIntent = new Intent(Mensajes.this, Mensajes.class);
                break;
        }

        startActivity(miIntent);
    }
}
