package gio.proyecto.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class Favoritos extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.favoritos);
    }

    public void onClick(View view) {

        //Intent miIntent = new Intent(MainActivity.this, Ingresar.class);

        Intent miIntent = null;

        switch (view.getId()) {
            case R.id.favorito:
                miIntent = new Intent(Favoritos.this, Favoritos.class);
                break;

            case R.id.cusca:
                miIntent = new Intent(Favoritos.this, Buscar.class);
                break;

            case R.id.home:
                miIntent = new Intent(Favoritos.this, Ingresar.class);
                break;

            case R.id.noti:
                miIntent = new Intent(Favoritos.this, Notificaciones.class);
                break;

            case R.id.msj:
                miIntent = new Intent(Favoritos.this, Mensajes.class);
                break;
        }

        startActivity(miIntent);
    }
}
